import type { Metadata } from "next";
import { Cormorant_Garamond, Manrope } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "DIESEL ROOM — ресторан и банкетный зал в Перми | Корпоративы, банкеты, вечеринки",
  description:
    "Ресторан-бар DIESEL ROOM в Перми на ул. Куйбышева, 47. Европейская кухня, 2 зала (180+30 чел), 4 бара, DJ, караоке, кальянная. Организация корпоративов, дней рождения и банкетов под ключ. Бронь: +7 (342) 202-11-00.",
  keywords: [
    "DIESEL ROOM",
    "ресторан Пермь",
    "банкетный зал Пермь",
    "корпоратив Пермь",
    "где отметить день рождения Пермь",
    "бар Пермь",
    "караоке Пермь",
    "клуб Пермь",
    "бизнес ланч Пермь",
    "Куйбышева 47 Пермь",
  ],
  authors: [{ name: "DIESEL ROOM" }],
  openGraph: {
    title: "DIESEL ROOM — ресторан и банкетный зал в Перми",
    description:
      "Европейская кухня, 2 зала, 4 бара, DJ, караоке, кальянная. Корпоративы и банкеты под ключ на Куйбышева 47.",
    url: "https://diesel-room.ru",
    siteName: "DIESEL ROOM",
    locale: "ru_RU",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "DIESEL ROOM — ресторан и банкетный зал в Перми",
    description:
      "Европейская кухня, 2 зала, 4 бара, DJ, караоке, кальянная. Корпоративы и банкеты под ключ.",
  },
  alternates: {
    canonical: "https://diesel-room.ru",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${cormorant.variable} ${manrope.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
