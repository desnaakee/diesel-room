import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { MenuSection } from "@/components/site/menu-section";
import { HallsSection } from "@/components/site/halls-section";
import { EventsSection } from "@/components/site/events-section";
import { PromotionsSection } from "@/components/site/promotions-section";
import { BookingSection } from "@/components/site/booking-section";
import { ContactsSection } from "@/components/site/contacts-section";
import { Footer } from "@/components/site/footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-x-hidden">
      <Header />
      <main className="flex-1">
        <Hero />
        <MenuSection />
        <HallsSection />
        <EventsSection />
        <PromotionsSection />
        <BookingSection />
        <ContactsSection />
      </main>
      <Footer />
    </div>
  );
}
