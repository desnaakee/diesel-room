import { NextRequest, NextResponse } from "next/server";

// API: приём заявки с формы бронирования и отправка в Telegram
//
// Для продакшена владелец сайта:
//   1. Создаёт бота через @BotFather → получает TELEGRAM_BOT_TOKEN
//   2. Пишет боту сообщение → через getUpdates получает TELEGRAM_CHAT_ID
//   3. Прописывает оба значения в .env
//   4. Устанавливает TELEGRAM_DEMO_MODE=false
//
// В демо-режиме (сейчас) — заявка просто логируется и возвращается успех.

const DEMO_MODE = process.env.TELEGRAM_DEMO_MODE !== "false";
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

type BookingPayload = {
  name: string;
  phone: string;
  date?: string;
  time?: string;
  guests?: string;
  eventType?: string;
  comment?: string;
};

function buildMessage(p: BookingPayload): string {
  const lines = [
    "🔥 Новая заявка с сайта DIESEL ROOM",
    "",
    `👤 Имя: ${p.name}`,
    `📞 Телефон: ${p.phone}`,
  ];
  if (p.date) lines.push(`📅 Дата: ${p.date}`);
  if (p.time) lines.push(`🕐 Время: ${p.time}`);
  if (p.guests) lines.push(`👥 Гостей: ${p.guests}`);
  if (p.eventType) lines.push(`🎉 Тип: ${p.eventType}`);
  if (p.comment) lines.push(`💬 Комментарий: ${p.comment}`);
  return lines.join("\n");
}

async function sendToTelegram(message: string) {
  if (!BOT_TOKEN || !CHAT_ID) {
    throw new Error("TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID не настроены");
  }
  const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: message,
      parse_mode: "HTML",
      disable_web_page_preview: true,
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Telegram API error: ${res.status} — ${err}`);
  }
  return await res.json();
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as BookingPayload;

    if (!body.name || !body.phone) {
      return NextResponse.json(
        { ok: false, error: "Имя и телефон обязательны" },
        { status: 400 }
      );
    }

    const message = buildMessage(body);

    if (DEMO_MODE || !BOT_TOKEN || !CHAT_ID) {
      console.log("\n========== ЗАЯВКА С САЙТА DIESEL ROOM ==========");
      console.log(message);
      console.log("==============================================\n");
      return NextResponse.json({
        ok: true,
        demo: true,
        message: "Заявка принята (демо-режим). В проде она уйдёт в Telegram.",
      });
    }

    await sendToTelegram(message);
    return NextResponse.json({ ok: true, demo: false });
  } catch (e) {
    console.error("[booking] error:", e);
    return NextResponse.json(
      { ok: false, error: "Не удалось отправить заявку. Позвоните нам: +7 (342) 202-11-00" },
      { status: 500 }
    );
  }
}
