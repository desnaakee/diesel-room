"use client";

import { Phone, MapPin, MessageCircle, Send } from "lucide-react";
import { RESTAURANT } from "@/lib/content";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t border-[color:var(--gold)]/20 bg-background/80 backdrop-blur-xl pt-12 pb-6 relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gold-gradient flex items-center justify-center">
                <span className="font-serif font-bold text-background text-lg">D</span>
              </div>
              <div className="leading-tight">
                <div className="font-serif text-xl font-semibold tracking-wide text-gold-gradient">
                  DIESEL ROOM
                </div>
                <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                  Пермь · с 2013
                </div>
              </div>
            </div>
            <p className="text-sm text-foreground/60 leading-relaxed">
              Ресторан, бар, караоке и банкетный зал в самом центре Перми.
              Место, где встречаются друзья.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">Навигация</h4>
            <ul className="space-y-2 text-sm">
              {[
                { href: "#menu", label: "Меню" },
                { href: "#halls", label: "Залы и банкеты" },
                { href: "#events", label: "Мероприятия" },
                { href: "#promotions", label: "Акции" },
                { href: "#booking", label: "Бронирование" },
                { href: "#contacts", label: "Контакты" },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-foreground/70 hover:text-[color:var(--gold-light)] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contacts */}
          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">Контакты</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[color:var(--gold)] mt-0.5 flex-shrink-0" />
                <span className="text-foreground/70">
                  г. {RESTAURANT.city}, {RESTAURANT.address}
                </span>
              </li>
              <li>
                <a
                  href={`tel:${RESTAURANT.phoneRaw}`}
                  className="flex items-center gap-3 text-foreground/70 hover:text-[color:var(--gold-light)] transition-colors"
                >
                  <Phone className="w-4 h-4 text-[color:var(--gold)] flex-shrink-0" />
                  {RESTAURANT.phone}
                </a>
              </li>
              <li className="flex flex-wrap gap-2 pt-2">
                <a
                  href={RESTAURANT.vk}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full glass-card flex items-center justify-center hover:border-[color:var(--gold)]/40 transition-all"
                  aria-label="VK"
                >
                  <MessageCircle className="w-4 h-4 text-[color:var(--gold)]" />
                </a>
                <a
                  href={RESTAURANT.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full glass-card flex items-center justify-center hover:border-[color:var(--gold)]/40 transition-all"
                  aria-label="Telegram"
                >
                  <Send className="w-4 h-4 text-[color:var(--gold)]" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="divider-gold opacity-30 my-6" />

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
          <div>
            © {year} DIESEL ROOM. Все права защищены.
          </div>
          <div className="flex items-center gap-4">
            <span>Вход 18+</span>
            <span className="opacity-30">·</span>
            <span>Своя парковка</span>
            <span className="opacity-30">·</span>
            <span>Демо-сайт</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
