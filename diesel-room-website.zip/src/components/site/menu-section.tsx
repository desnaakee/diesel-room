"use client";

import { motion } from "framer-motion";
import {
  Coffee,
  Croissant,
  Fish,
  Salad,
  Soup,
  Flame,
  Beef,
  Pizza,
  UtensilsCrossed,
  Carrot,
  CakeSlice,
  Baby,
  Wine,
  Utensils,
  Phone,
  ArrowRight,
  type LucideIcon,
} from "lucide-react";
import { MENU } from "@/lib/content";
import { SectionTitle } from "./section-title";
import { RESTAURANT } from "@/lib/content";

const ICONS: Record<string, LucideIcon> = {
  Coffee,
  Croissant,
  Fish,
  Salad,
  Soup,
  Flame,
  Beef,
  Pizza,
  UtensilsCrossed,
  Carrot,
  CakeSlice,
  Baby,
  Wine,
};

export function MenuSection() {
  return (
    <section id="menu" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle
          eyebrow="Кухня"
          title="Меню"
          subtitle="Более 150 блюд европейской кухни от шеф-повара: свежие морепродукты, томлёное мясо, авторские салаты, фирменные бургеры и десерты."
        />

        {/* Категории как «витра» разнообразия — некликабельные чипсы */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mt-12 mb-12 -mx-4 px-4 overflow-x-auto"
        >
          <div className="flex flex-wrap gap-2 md:gap-3 justify-center max-w-5xl mx-auto">
            {MENU.map((cat) => {
              const Icon = ICONS[cat.icon] ?? Coffee;
              return (
                <div
                  key={cat.id}
                  className="flex items-center gap-2 px-4 md:px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap glass-card text-foreground/80"
                >
                  <Icon className="w-4 h-4 text-[color:var(--gold)]" />
                  {cat.title}
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Центральный блок вместо позиций */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="max-w-3xl mx-auto"
        >
          <div className="glass-card rounded-3xl p-8 md:p-12 text-center relative overflow-hidden group hover:glow-gold transition-all duration-500">
            {/* Декоративные элементы */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-px bg-gradient-to-r from-transparent via-[color:var(--gold)] to-transparent opacity-60" />
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-32 h-px bg-gradient-to-r from-transparent via-[color:var(--gold)] to-transparent opacity-60" />

            <div className="relative">
              {/* Иконка */}
              <div className="inline-flex w-16 h-16 rounded-2xl bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/30 items-center justify-center mb-6">
                <Utensils className="w-8 h-8 text-[color:var(--gold)]" />
              </div>

              <h3 className="font-serif text-3xl md:text-4xl font-semibold mb-4 text-gold-gradient">
                Полное меню — в ресторане
              </h3>

              <p className="text-base md:text-lg text-foreground/70 leading-relaxed mb-8 max-w-xl mx-auto">
                Мы готовим более 150 блюд: от фирменного «Вин Дизель Бургера»
                до бефстроганова из говяжьего языка с белыми грибами.
                Средний чек — {RESTAURANT.averageCheck}. Бизнес-ланч от 130 ₽.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
                <a
                  href={`tel:${RESTAURANT.phoneRaw}`}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full glass-card hover:border-[color:var(--gold)]/50 hover:bg-[color:var(--gold)]/10 transition-all text-sm font-medium"
                >
                  <Phone className="w-4 h-4 text-[color:var(--gold)]" />
                  {RESTAURANT.phone}
                </a>
                <a
                  href="#booking"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gold-gradient text-background hover:opacity-90 transition-opacity text-sm font-medium glow-gold"
                >
                  Забронировать стол
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
