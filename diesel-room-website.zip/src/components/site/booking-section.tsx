"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, CheckCircle2, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { RESTAURANT } from "@/lib/content";
import { SectionTitle } from "./section-title";

const EVENT_TYPES = [
  "Просто ужин",
  "День рождения",
  "Корпоратив",
  "Свадьба",
  "Девичник / Вечеринка",
  "Бизнес-встреча",
  "Другое",
];

export function BookingSection() {
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  const [form, setForm] = useState({
    name: "",
    phone: "",
    date: "",
    time: "",
    guests: "",
    eventType: "",
    comment: "",
  });

  const updateField = <K extends keyof typeof form>(key: K, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      toast({
        title: "Заполните обязательные поля",
        description: "Имя и телефон нужны, чтобы мы могли с вами связаться.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/booking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Не удалось отправить");
      }

      setSuccess(true);
      toast({
        title: "Заявка принята!",
        description: data.demo
          ? "Демо-режим: заявка залогирована на сервере. В проде уйдёт в Telegram."
          : "Мы свяжемся с вами в течение 15 минут.",
      });

      setForm({
        name: "",
        phone: "",
        date: "",
        time: "",
        guests: "",
        eventType: "",
        comment: "",
      });
    } catch (err) {
      toast({
        title: "Ошибка отправки",
        description:
          err instanceof Error
            ? err.message
            : "Позвоните нам: +7 (342) 202-11-00",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="booking" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-[400px] bg-gradient-to-b from-[color:var(--gold)]/10 to-transparent blur-3xl" />
      </div>

      <div className="container mx-auto px-4 md:px-6 relative">
        <div className="max-w-5xl mx-auto">
          <SectionTitle
            eyebrow="Бронирование"
            title="Забронировать стол"
            subtitle="Оставьте заявку — менеджер свяжется с вами в течение 15 минут и подберёт идеальный стол под ваше событие."
          />

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 mt-12">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-3 glass-card rounded-2xl p-6 md:p-8"
            >
              {success ? (
                <div className="flex flex-col items-center justify-center text-center py-12">
                  <CheckCircle2 className="w-16 h-16 text-[color:var(--gold)] mb-4" />
                  <h3 className="font-serif text-2xl font-semibold mb-2 text-foreground">
                    Заявка принята!
                  </h3>
                  <p className="text-sm text-muted-foreground max-w-sm mb-6">
                    Мы свяжемся с вами в течение 15 минут. Для срочной брони
                    позвоните по номеру ниже.
                  </p>
                  <Button
                    variant="outline"
                    className="border-[color:var(--gold)]/40 text-foreground hover:bg-[color:var(--gold)]/10"
                    onClick={() => setSuccess(false)}
                  >
                    Отправить ещё одну
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">
                        Имя <span className="text-[color:var(--gold)]">*</span>
                      </Label>
                      <Input
                        id="name"
                        value={form.name}
                        onChange={(e) => updateField("name", e.target.value)}
                        placeholder="Как к вам обращаться"
                        className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">
                        Телефон <span className="text-[color:var(--gold)]">*</span>
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={form.phone}
                        onChange={(e) => updateField("phone", e.target.value)}
                        placeholder="+7 (___) ___-__-__"
                        className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date">Дата</Label>
                      <Input
                        id="date"
                        type="date"
                        value={form.date}
                        onChange={(e) => updateField("date", e.target.value)}
                        className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="time">Время</Label>
                      <Input
                        id="time"
                        type="time"
                        value={form.time}
                        onChange={(e) => updateField("time", e.target.value)}
                        className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="guests">Гостей</Label>
                      <Input
                        id="guests"
                        type="number"
                        min={1}
                        max={200}
                        value={form.guests}
                        onChange={(e) => updateField("guests", e.target.value)}
                        placeholder="2"
                        className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="eventType">Тип события</Label>
                    <Select
                      value={form.eventType}
                      onValueChange={(v) => updateField("eventType", v)}
                    >
                      <SelectTrigger className="bg-background/60 border-border/60 focus:border-[color:var(--gold)]">
                        <SelectValue placeholder="Выберите тип мероприятия" />
                      </SelectTrigger>
                      <SelectContent>
                        {EVENT_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="comment">Комментарий</Label>
                    <Textarea
                      id="comment"
                      value={form.comment}
                      onChange={(e) => updateField("comment", e.target.value)}
                      placeholder="Пожелания по меню, особые запросы, детали события..."
                      rows={3}
                      className="bg-background/60 border-border/60 focus:border-[color:var(--gold)] resize-none"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={submitting}
                    size="lg"
                    className="w-full bg-gold-gradient text-background hover:opacity-90 font-medium py-6 glow-gold disabled:opacity-60"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Отправляем...
                      </>
                    ) : (
                      "Отправить заявку"
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    Нажимая «Отправить», вы соглашаетесь на обработку
                    персональных данных
                  </p>
                </form>
              )}
            </motion.div>

            {/* Sidebar */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="lg:col-span-2 flex flex-col gap-4"
            >
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-serif text-xl font-semibold mb-4 text-foreground">
                  Позвонить напрямую
                </h3>
                <a
                  href={`tel:${RESTAURANT.phoneRaw}`}
                  className="flex items-center gap-3 text-lg font-medium text-[color:var(--gold-light)] hover:text-[color:var(--gold)] transition-colors mb-2"
                >
                  <Phone className="w-5 h-5" />
                  {RESTAURANT.phone}
                </a>
                <p className="text-xs text-muted-foreground">
                  Ежедневно с 11:00 до последнего гостя
                </p>
              </div>

              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-serif text-xl font-semibold mb-3 text-foreground">
                  Часы работы
                </h3>
                {RESTAURANT.hours.map((h) => (
                  <div
                    key={h.day}
                    className="flex justify-between items-center py-2 border-b border-border/30 last:border-0"
                  >
                    <span className="text-sm text-foreground/70">{h.day}</span>
                    <span className="text-sm font-medium text-foreground">
                      {h.time}
                    </span>
                  </div>
                ))}
                <div className="mt-3 pt-3 border-t border-border/30">
                  <div className="text-xs text-muted-foreground">Бизнес-ланч</div>
                  <div className="text-sm font-medium text-[color:var(--gold-light)]">
                    {RESTAURANT.businessLunch}
                  </div>
                </div>
              </div>

              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-serif text-xl font-semibold mb-2 text-foreground">
                  Средний чек
                </h3>
                <div className="text-3xl font-serif font-semibold text-gold-gradient mb-1">
                  {RESTAURANT.averageCheck}
                </div>
                <p className="text-xs text-muted-foreground">
                  Вход 18+ · Своя парковка
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
