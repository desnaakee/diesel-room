"use client";

import { motion } from "framer-motion";
import {
  Utensils,
  Wine,
  Cake,
  Gift,
  Beer,
  type LucideIcon,
} from "lucide-react";
import { PROMOTIONS } from "@/lib/content";
import { SectionTitle } from "./section-title";

const ICONS: Record<string, LucideIcon> = {
  Utensils,
  Wine,
  Cake,
  Gift,
  Beer,
};

export function PromotionsSection() {
  return (
    <section id="promotions" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle
          eyebrow="Выгодно"
          title="Акции"
          subtitle="Программа лояльности для наших гостей: от бизнес-ланча до депозитных подарков и комбо-предложений."
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-12 max-w-6xl mx-auto">
          {PROMOTIONS.map((promo, idx) => {
            const Icon = ICONS[promo.icon] ?? Gift;
            return (
              <motion.div
                key={promo.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ duration: 0.5, delay: idx * 0.07 }}
                className="glass-card rounded-2xl p-6 hover:glow-gold hover:border-[color:var(--gold)]/40 transition-all duration-300 group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-lg bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/25 flex items-center justify-center flex-shrink-0 group-hover:bg-gold-gradient transition-all duration-300">
                    <Icon className="w-5 h-5 text-[color:var(--gold)] group-hover:text-background transition-colors" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-serif text-xl font-semibold mb-1 text-foreground group-hover:text-[color:var(--gold-light)] transition-colors">
                      {promo.title}
                    </h3>
                    <p className="text-sm text-foreground/80 mb-2 leading-snug">
                      {promo.description}
                    </p>
                    <p className="text-xs text-muted-foreground">{promo.detail}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
