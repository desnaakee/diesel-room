"use client";

import { motion } from "framer-motion";
import { ChevronDown, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { STATS, RESTAURANT } from "@/lib/content";

export function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-12"
    >
      {/* Background effects */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Радужный свет сверху */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-[600px] bg-gradient-to-b from-[color:var(--gold)]/20 via-[color:var(--gold)]/5 to-transparent blur-3xl" />
        {/* Лёгкая текстура */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40'%3E%3Cpath d='M0 0h40v40H0z' fill='none'/%3E%3Cpath d='M20 0l3 17L40 20 23 23 20 40 17 23 0 20 17 17z' fill='%23c9a961'/%3E%3C/svg%3E\")",
          }}
        />
        {/* Лучи света */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rotate-12 opacity-20">
          <div className="absolute inset-0 bg-[conic-gradient(from_0deg,transparent_0deg,rgba(201,169,97,0.15)_30deg,transparent_60deg,rgba(201,169,97,0.15)_120deg,transparent_180deg,rgba(201,169,97,0.15)_240deg,transparent_300deg)]" />
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          {/* Top badge */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full glass-card"
          >
            <Sparkles className="w-3.5 h-3.5 text-[color:var(--gold)] animate-shimmer" />
            <span className="text-xs uppercase tracking-[0.3em] text-[color:var(--gold-light)]">
              Ресторан · Бар · Караоке · Банкетный зал
            </span>
          </motion.div>

          {/* Main title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-serif font-semibold text-6xl md:text-8xl lg:text-9xl leading-[0.9] tracking-tight mb-6"
          >
            <span className="block text-gold-gradient">DIESEL</span>
            <span className="block text-gold-gradient">ROOM</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-lg md:text-xl text-foreground/70 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Место для деловых и романтических встреч, семейных обедов и
            зажигательных вечеринок с друзьями. Европейская кухня, 4 бара,
            DJ и караоке — в самом центре Перми.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
          >
            <Button
              asChild
              size="lg"
              className="bg-gold-gradient text-background hover:opacity-90 font-medium px-8 py-6 text-base glow-gold"
            >
              <a href="#booking">Забронировать стол</a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-[color:var(--gold)]/40 text-foreground hover:bg-[color:var(--gold)]/10 hover:text-[color:var(--gold-light)] hover:border-[color:var(--gold)] font-medium px-8 py-6 text-base"
            >
              <a href="#menu">Смотреть меню</a>
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto"
          >
            {STATS.map((stat) => (
              <div
                key={stat.label}
                className="text-center"
              >
                <div className="font-serif text-4xl md:text-5xl font-semibold text-gold-gradient mb-1">
                  {stat.value}
                </div>
                <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground"
      >
        <span className="text-[10px] uppercase tracking-[0.3em]">Листайте</span>
        <ChevronDown className="w-5 h-5 text-[color:var(--gold)] animate-bounce" />
      </motion.div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
    </section>
  );
}
