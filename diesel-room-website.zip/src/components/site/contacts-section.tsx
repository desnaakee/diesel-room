"use client";

import { motion } from "framer-motion";
import { MapPin, Phone, Clock, MessageCircle, Send } from "lucide-react";
import { RESTAURANT } from "@/lib/content";
import { SectionTitle } from "./section-title";

export function ContactsSection() {
  // Координаты ул. Куйбышева 47, Пермь
  // Approx: 58.0105° N, 56.2302° E
  const yandexMapSrc =
    "https://yandex.ru/map-widget/v1/?ll=56.230200%2C58.010500&mode=search&sctx=ZAAAAAgBEAAaKAoSCRjOvb%2Bz0j1AESDxQ4AvyTtEhIJWP%2F%2F%2F%2F%2F%2F%2F%2FAREiARAAGgAoZnIByaAA&z=16&text=%D0%9A%D1%83%D0%B9%D0%B1%D1%8B%D1%88%D0%B5%D0%B2%D0%B0%2047%20%D0%9F%D0%B5%D1%80%D0%BC%D1%8C";

  return (
    <section id="contacts" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-4 md:px-6">
        <SectionTitle
          eyebrow="Где мы"
          title="Контакты"
          subtitle="В самом центре Перми, на ул. Куйбышева 47. Своя парковка, удобный вход с улицы."
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12 max-w-6xl mx-auto">
          {/* Map */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass-card rounded-2xl overflow-hidden h-[400px] lg:h-full min-h-[400px] relative"
          >
            <iframe
              src={yandexMapSrc}
              width="100%"
              height="100%"
              frameBorder="0"
              allowFullScreen
              title="Карта — DIESEL ROOM на Куйбышева 47, Пермь"
              className="absolute inset-0 grayscale-[0.3] contrast-110"
              style={{ filter: "invert(0.9) hue-rotate(180deg) brightness(0.9) contrast(0.9)" }}
            />
          </motion.div>

          {/* Contact details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex flex-col gap-4"
          >
            <div className="glass-card rounded-2xl p-6 hover:border-[color:var(--gold)]/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-lg bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/25 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-[color:var(--gold)]" />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-semibold mb-1">Адрес</h3>
                  <p className="text-foreground/80">
                    г. {RESTAURANT.city}, {RESTAURANT.address}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {RESTAURANT.district}
                  </p>
                </div>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 hover:border-[color:var(--gold)]/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-lg bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/25 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-[color:var(--gold)]" />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-semibold mb-1">Телефон</h3>
                  <a
                    href={`tel:${RESTAURANT.phoneRaw}`}
                    className="text-foreground/80 hover:text-[color:var(--gold-light)] transition-colors text-lg"
                  >
                    {RESTAURANT.phone}
                  </a>
                </div>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 hover:border-[color:var(--gold)]/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-lg bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/25 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-[color:var(--gold)]" />
                </div>
                <div className="flex-1">
                  <h3 className="font-serif text-xl font-semibold mb-2">Часы работы</h3>
                  {RESTAURANT.hours.map((h) => (
                    <div key={h.day} className="flex justify-between text-sm py-1">
                      <span className="text-foreground/70">{h.day}</span>
                      <span className="text-foreground">{h.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 hover:border-[color:var(--gold)]/30 transition-colors">
              <h3 className="font-serif text-xl font-semibold mb-3">Мы в соцсетях</h3>
              <div className="flex flex-wrap gap-3">
                <a
                  href={RESTAURANT.vk}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-full glass-card hover:border-[color:var(--gold)]/40 hover:bg-[color:var(--gold)]/10 transition-all"
                >
                  <MessageCircle className="w-4 h-4 text-[color:var(--gold)]" />
                  <span className="text-sm font-medium">ВКонтакте</span>
                </a>
                <a
                  href={RESTAURANT.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-full glass-card hover:border-[color:var(--gold)]/40 hover:bg-[color:var(--gold)]/10 transition-all"
                >
                  <Send className="w-4 h-4 text-[color:var(--gold)]" />
                  <span className="text-sm font-medium">Telegram</span>
                </a>
                <a
                  href={RESTAURANT.taplink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-full glass-card hover:border-[color:var(--gold)]/40 hover:bg-[color:var(--gold)]/10 transition-all"
                >
                  <span className="text-sm font-medium">Taplink</span>
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
