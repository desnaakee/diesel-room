"use client";

import { motion } from "framer-motion";
import { Check, Users } from "lucide-react";
import { HALLS } from "@/lib/content";
import { SectionTitle } from "./section-title";
import { Button } from "@/components/ui/button";

export function HallsSection() {
  return (
    <section id="halls" className="py-20 md:py-32 relative luxury-bg">
      <div className="container mx-auto px-4 md:px-6 relative">
        <SectionTitle
          eyebrow="Пространство"
          title="Залы и банкеты"
          subtitle="Четыре разные атмосферы под любое настроение: от камерного ужина до масштабного корпоратива на 180 гостей."
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-12 max-w-6xl mx-auto">
          {HALLS.map((hall, idx) => (
            <motion.div
              key={hall.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="glass-card rounded-2xl overflow-hidden group hover:glow-gold transition-all duration-500"
            >
              {/* Image / gradient placeholder */}
              <div className="relative h-56 md:h-64 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[color:var(--gold)]/20 via-background to-background" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Users className="w-12 h-12 text-[color:var(--gold)]/40 mx-auto mb-2" />
                    <div className="font-serif text-3xl font-semibold text-[color:var(--gold-light)]/80">
                      {hall.capacity}
                    </div>
                  </div>
                </div>
                {/* Accent label */}
                <div className="absolute top-4 left-4">
                  <span className="inline-block px-3 py-1 rounded-full bg-background/80 backdrop-blur text-xs uppercase tracking-wider text-[color:var(--gold-light)] border border-[color:var(--gold)]/30">
                    {hall.accent}
                  </span>
                </div>
              </div>

              {/* Body */}
              <div className="p-6 md:p-8">
                <h3 className="font-serif text-2xl md:text-3xl font-semibold mb-3 text-foreground">
                  {hall.name}
                </h3>
                <p className="text-sm text-foreground/70 leading-relaxed mb-5">
                  {hall.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {hall.features.map((feat) => (
                    <span
                      key={feat}
                      className="inline-flex items-center gap-1.5 text-xs text-foreground/80 px-3 py-1.5 rounded-full bg-secondary/60 border border-border/40"
                    >
                      <Check className="w-3 h-3 text-[color:var(--gold)]" />
                      {feat}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button
            asChild
            size="lg"
            className="bg-gold-gradient text-background hover:opacity-90 font-medium px-8 py-6"
          >
            <a href="#booking">Узнать свободные даты</a>
          </Button>
        </div>
      </div>
    </section>
  );
}
