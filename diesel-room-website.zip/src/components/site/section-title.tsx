"use client";

import { motion } from "framer-motion";

type Props = {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
};

export function SectionTitle({ eyebrow, title, subtitle, center = true }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6 }}
      className={center ? "text-center max-w-3xl mx-auto" : "max-w-3xl"}
    >
      {eyebrow && (
        <div
          className={`flex items-center gap-3 mb-4 ${
            center ? "justify-center" : ""
          }`}
        >
          <div className="w-8 h-px bg-[color:var(--gold)]/60" />
          <span className="text-xs uppercase tracking-[0.3em] text-[color:var(--gold)]">
            {eyebrow}
          </span>
          <div className="w-8 h-px bg-[color:var(--gold)]/60" />
        </div>
      )}
      <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl font-semibold mb-4 text-gold-gradient">
        {title}
      </h2>
      {subtitle && (
        <p className="text-base md:text-lg text-foreground/70 leading-relaxed">
          {subtitle}
        </p>
      )}
    </motion.div>
  );
}
