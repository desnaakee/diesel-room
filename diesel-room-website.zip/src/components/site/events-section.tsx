"use client";

import { motion } from "framer-motion";
import { Check, PartyPopper, Cake, Heart } from "lucide-react";
import { EVENTS_FORMATS } from "@/lib/content";
import { SectionTitle } from "./section-title";
import { Button } from "@/components/ui/button";

const ICONS = [PartyPopper, Cake, Heart];

export function EventsSection() {
  return (
    <section id="events" className="py-20 md:py-32 relative">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-[color:var(--gold)]/5 rounded-full blur-3xl" />
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-[color:var(--gold)]/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 md:px-6 relative">
        <SectionTitle
          eyebrow="Под ключ"
          title="Мероприятия"
          subtitle="Организация банкетов любой сложности: от камерного дня рождения до масштабного корпоратива. Ведущий, диджей, шоу-программа, фотограф — всё включено."
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-12 max-w-6xl mx-auto">
          {EVENTS_FORMATS.map((event, idx) => {
            const Icon = ICONS[idx] ?? PartyPopper;
            return (
              <motion.div
                key={event.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className="glass-card rounded-2xl p-6 md:p-8 group hover:glow-gold transition-all duration-500 relative overflow-hidden"
              >
                {/* Top accent line */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[color:var(--gold)] to-transparent opacity-50" />

                <div className="flex items-start justify-between mb-6">
                  <div className="w-14 h-14 rounded-xl bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/30 flex items-center justify-center group-hover:bg-gold-gradient group-hover:border-[color:var(--gold)] transition-all duration-300">
                    <Icon className="w-7 h-7 text-[color:var(--gold)] group-hover:text-background transition-colors" />
                  </div>
                  <div className="text-right">
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">
                      Цена
                    </div>
                    <div className="font-serif text-xl font-semibold text-gold-gradient">
                      {event.price}
                    </div>
                  </div>
                </div>

                <h3 className="font-serif text-2xl md:text-3xl font-semibold mb-3 text-foreground">
                  {event.title}
                </h3>
                <p className="text-sm text-foreground/70 leading-relaxed mb-6">
                  {event.description}
                </p>

                <div className="space-y-2.5 mb-6">
                  {event.includes.map((item) => (
                    <div key={item} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-[color:var(--gold)] mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-foreground/80">{item}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <p className="text-sm text-muted-foreground mb-6 max-w-2xl mx-auto">
            Сборные корпоративы с 11 по 31 декабря. Шоу-программа, артисты, ведущий, диджей,
            розыгрыши, подарки и безлимитный бесплатный кофе в 2027 году — всё включено.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-gold-gradient text-background hover:opacity-90 font-medium px-8 py-6 glow-gold"
          >
            <a href="#booking">Рассчитать стоимость</a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
