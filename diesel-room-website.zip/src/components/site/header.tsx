"use client";

import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RESTAURANT } from "@/lib/content";

const NAV_ITEMS = [
  { href: "#menu", label: "Меню" },
  { href: "#halls", label: "Залы" },
  { href: "#events", label: "Мероприятия" },
  { href: "#promotions", label: "Акции" },
  { href: "#contacts", label: "Контакты" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-background/90 backdrop-blur-xl border-b border-[color:var(--gold)]/20 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#top" className="flex items-center gap-3 group">
          <div className="relative w-10 h-10 md:w-12 md:h-12 rounded-full bg-gold-gradient flex items-center justify-center luxury-shadow">
            <span className="font-serif font-bold text-background text-lg md:text-xl">D</span>
          </div>
          <div className="leading-tight">
            <div className="font-serif text-xl md:text-2xl font-semibold tracking-wide text-gold-gradient">
              DIESEL ROOM
            </div>
            <div className="text-[10px] md:text-xs uppercase tracking-[0.3em] text-muted-foreground">
              Пермь · Куйбышева 47
            </div>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-foreground/80 hover:text-[color:var(--gold)] transition-colors relative group"
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-[color:var(--gold)] transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href={`tel:${RESTAURANT.phoneRaw}`}
            className="flex items-center gap-2 text-sm text-foreground/70 hover:text-[color:var(--gold)] transition-colors"
          >
            <Phone className="w-4 h-4" />
            <span className="hidden xl:inline">{RESTAURANT.phone}</span>
          </a>
          <Button
            asChild
            size="sm"
            className="bg-gold-gradient text-background hover:opacity-90 font-medium"
          >
            <a href="#booking">Забронировать</a>
          </Button>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setOpen(!open)}
          className="lg:hidden p-2 text-foreground"
          aria-label="Меню"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden bg-background/95 backdrop-blur-xl border-t border-[color:var(--gold)]/20 mt-3">
          <nav className="container mx-auto px-4 py-6 flex flex-col gap-4">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="text-base font-medium text-foreground/80 hover:text-[color:var(--gold)] transition-colors py-2 border-b border-border/30"
              >
                {item.label}
              </a>
            ))}
            <div className="flex flex-col gap-3 pt-4">
              <a
                href={`tel:${RESTAURANT.phoneRaw}`}
                className="flex items-center gap-2 text-foreground/80"
              >
                <Phone className="w-4 h-4 text-[color:var(--gold)]" />
                {RESTAURANT.phone}
              </a>
              <Button
                asChild
                className="bg-gold-gradient text-background hover:opacity-90"
                onClick={() => setOpen(false)}
              >
                <a href="#booking">Забронировать стол</a>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
