# DIESEL ROOM — сайт ресторана

Тёмный премиум-лендинг ресторана DIESEL ROOM (Пермь, Куйбышева 47).
Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui.

## Разделы сайта

- Hero с оффером и CTA
- Меню (17 категорий, краткое описание, без позиций)
- Залы и банкеты (4 зала: большой 180 чел, малый 30 чел, караоке, кальянная)
- Мероприятия (корпоративы, дни рождения, свадьбы)
- Акции (бизнес-ланч, микс-дринки, депозитные подарки)
- Форма бронирования → отправка в Telegram
- Контакты + Яндекс.Карта
- Footer с навигацией и контактами

## Запуск локально

```bash
bun install
bun run dev
# открыть http://localhost:3000
```

## Деплой на Vercel (бесплатно, 5 минут)

### Вариант 1: через GitHub (рекомендуется)

1. Создай репозиторий на [github.com](https://github.com/new)
2. Залей код:
   ```bash
   git init
   git add .
   git commit -m "DIESEL ROOM website"
   git branch -M main
   git remote add origin https://github.com/<username>/<repo>.git
   git push -u origin main
   ```
3. Зайди на [vercel.com/new](https://vercel.com/new)
4. Нажми **Import Git Repository** → выбери репозиторий
5. Vercel сам определит Next.js — нажми **Deploy**
6. Через 1-2 минуты получишь ссылку вида `diesel-room.vercel.app`

### Вариант 2: через Vercel CLI (без GitHub)

1. Установи CLI:
   ```bash
   npm i -g vercel
   ```
2. Залогинься (откроется браузер):
   ```bash
   vercel login
   ```
3. В папке проекта запусти:
   ```bash
   vercel
   ```
4. Отвечай на вопросы (можно все Enter) → получишь preview-ссылку
5. Для продакшен-ссылки:
   ```bash
   vercel --prod
   ```

## Подключение Telegram-бота (для реальных заявок)

1. Открой Telegram, найди [@BotFather](https://t.me/BotFather)
2. Напиши `/newbot` → придумай имя → получи **токен**
3. Напиши своему боту любое сообщение
4. Открой в браузере:
   ```
   https://api.telegram.org/bot<ТВОЙ_ТОКЕН>/getUpdates
   ```
5. В ответе найди `"chat":{"id":123456789` — это твой **chat_id**
6. В Vercel: Settings → Environment Variables → добавь:
   ```
   TELEGRAM_BOT_TOKEN = <токен>
   TELEGRAM_CHAT_ID   = <chat_id>
   TELEGRAM_DEMO_MODE = false
   ```
7. Нажми **Redeploy** — заявки пойдут в Telegram

## Кастомный домен

В Vercel: Settings → Domains → Add → введи `diesel-room.ru`
(домен нужно купить отдельно — ~200₽/год на reg.ru или nic.ru)
